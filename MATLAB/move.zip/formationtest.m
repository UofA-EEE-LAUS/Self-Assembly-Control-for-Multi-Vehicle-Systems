 %MATLAB script for the rover formation
%---------------------------------SETUP----------------------------------%
% load api library
vrep=remApi('remoteApi');
% close all the potential link
vrep.simxFinish(-1);
%set up connection to v-rep simulation on port 19999
clientID=vrep.simxStart('127.0.0.1',19999,true,true,5000,5);
% open the synchronous mode to control the objects in vrep
vrep.simxSynchronous(clientID,true);
% Simulation Initialization
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);
%clientID is -1 if the connection to the server was NOT possible
if (clientID>-1)
    disp('connected to v-rep');  
     elapsedTime = 1;


        %Get 3 rovers' position
        [returnCode,rover0]=vrep.simxGetObjectHandle(clientID,strcat('rover0'),vrep.simx_opmode_blocking);
        [returnCode,rover1]=vrep.simxGetObjectHandle(clientID,strcat('rover1'),vrep.simx_opmode_blocking);
        [returnCode,rover2]=vrep.simxGetObjectHandle(clientID,strcat('rover2'),vrep.simx_opmode_blocking);
        [returnCode,position0]=vrep.simxGetObjectPosition(clientID,rover0,-1,vrep.simx_opmode_blocking);
        [returnCode,position1]=vrep.simxGetObjectPosition(clientID,rover1,-1,vrep.simx_opmode_blocking);
        [returnCode,position2]=vrep.simxGetObjectPosition(clientID,rover2,-1,vrep.simx_opmode_blocking);
        position=[position0; position1; position2];
        positionl0=position0;
        positionl1=position1;
        positionl2=position2;
        
        for loop = 1:50
        tic
        %Get 
        %Line Formation
        [returnCode,rover0]=vrep.simxGetObjectHandle(clientID,strcat('rover0'),vrep.simx_opmode_blocking);
        [returnCode,rover1]=vrep.simxGetObjectHandle(clientID,strcat('rover1'),vrep.simx_opmode_blocking);
        [returnCode,rover2]=vrep.simxGetObjectHandle(clientID,strcat('rover2'),vrep.simx_opmode_blocking);
        [returnCode,position0]=vrep.simxGetObjectPosition(clientID,rover0,-1,vrep.simx_opmode_blocking);
        [returnCode,position1]=vrep.simxGetObjectPosition(clientID,rover1,-1,vrep.simx_opmode_blocking);
        [returnCode,position2]=vrep.simxGetObjectPosition(clientID,rover2,-1,vrep.simx_opmode_blocking);
        x0=position0(:,1);
        y0=position0(:,2);
        x1=position1(:,1);
        y1=position1(:,2);
        x2=position2(:,1);
        y2=position2(:,2);
        dx=5.6172;
        dy=-2.9351;
        d=0.35;
        [xl0,yl0,xl1,yl1,xl2,yl2]=linedistanceformation(x0,y0,x1,y1,x2,y2,d);
        %Get 3 rovers' position
        [positionl0]=movetest3(xl0,yl0,positionl0,elapsedTime,int2str(0),vrep,clientID);
%         [positionl0]=movetest3(5.6172,-2.9351,positionl0,elapsedTime,int2str(0),vrep,clientID);
        [positionl1]=movetest3(xl1,yl1,positionl1,elapsedTime,int2str(1),vrep,clientID);
        [positionl2]=movetest3(xl2,yl2,positionl2,elapsedTime,int2str(2),vrep,clientID);
%         Move(xl2,yl2,int2str(2),clientID,vrep);
%         Move(xl1,yl1,int2str(1),clientID,vrep);
%         Move(xl0,yl0,int2str(0),clientID,vrep);
%        Move1(xl2,yl2,3/2*pi,int2str(2),clientID,vrep);
%        Move1(xl1,yl1,3/2*pi,int2str(1),clientID,vrep);
%        Move1(xl0,yl0,3/2*pi,int2str(0),clientID,vrep);
    %    MoveTheta(xl2,yl2,positionl2,3*pi/2,int2str(2),clientID,vrep);
    %    MoveTheta(xl1,yl1,positionl1,3*pi/2,int2str(1),clientID,vrep);
    %    MoveTheta(xl0,yl0,positionl0,3*pi/2,int2str(0),clientID,vrep);
        
        
        
        elapsedTime = toc;
    end
    pause(1);
    
     for loop=1:10
      tic;
    [returnCode,rover0]=vrep.simxGetObjectHandle(clientID,strcat('rover0'),vrep.simx_opmode_blocking);
    [returnCode,rover1]=vrep.simxGetObjectHandle(clientID,strcat('rover1'),vrep.simx_opmode_blocking);
    [returnCode,rover2]=vrep.simxGetObjectHandle(clientID,strcat('rover2'),vrep.simx_opmode_blocking);
    [returnCode,positions0]=vrep.simxGetObjectPosition(clientID,rover0,-1,vrep.simx_opmode_blocking);
    [returnCode,positions1]=vrep.simxGetObjectPosition(clientID,rover1,-1,vrep.simx_opmode_blocking);
    [returnCode,positions2]=vrep.simxGetObjectPosition(clientID,rover2,-1,vrep.simx_opmode_blocking);
    position=[positions0; positions1; positions2];
    positiont0=positions0;
    positiont1=positions1;
    positiont2=positions2;
    
    xs0=positions0(:,1);
    ys0=positions0(:,2);
    xs1=positions1(:,1);
    ys1=positions1(:,2);
    xs2=positions2(:,1);
    ys2=positions2(:,2);
    dt01=sqrt((abs(xs0-xs1)^2)+(abs(ys0-ys1)^2));
    dt02=sqrt((abs(xs0-xs2)^2)+(abs(ys0-ys2)^2));
    
    gripper(dt01,int2str(1),clientID,vrep);
    gripper(dt02,int2str(2),clientID,vrep);
    
  end
    pause(15);
    
       %destroy connection to v-rep simulation
    vrep.simxPauseSimulation(clientID,vrep.simx_opmode_oneshot_wait);
else
    disp('Failed connecting to remote API server');
end
vrep.delete()
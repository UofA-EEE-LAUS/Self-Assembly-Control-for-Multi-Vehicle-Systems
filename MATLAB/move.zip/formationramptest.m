%MATLAB script for the rover formation
%---------------------------------SETUP----------------------------------%
% load api library
vrep=remApi('remoteApi');
% close all the potential link
vrep.simxFinish(-1);
%set up connection to v-rep simulation on port 19999
clientID=vrep.simxStart('127.0.0.1',19999,true,true,5000,5);
% open the synchronous mode to control the objects in vrep
vrep.simxSynchronous(clientID,true);
% Simulation Initialization
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);
%clientID is -1 if the connection to the server was NOT possible
if (clientID>-1)
    disp('connected to v-rep');
    %------------------------------CODE HERE------------------------------

        tic
        %Get 3 rovers' position
        [returnCode,rover0]=vrep.simxGetObjectHandle(clientID,strcat('rover0'),vrep.simx_opmode_blocking);
        [returnCode,rover1]=vrep.simxGetObjectHandle(clientID,strcat('rover1'),vrep.simx_opmode_blocking);
        [returnCode,rover2]=vrep.simxGetObjectHandle(clientID,strcat('rover2'),vrep.simx_opmode_blocking);
        [returnCode,position0]=vrep.simxGetObjectPosition(clientID,rover0,-1,vrep.simx_opmode_blocking);
        [returnCode,position1]=vrep.simxGetObjectPosition(clientID,rover1,-1,vrep.simx_opmode_blocking);
        [returnCode,position2]=vrep.simxGetObjectPosition(clientID,rover2,-1,vrep.simx_opmode_blocking);
        position=[position0; position1; position2];
        positionl0=position0;
        positionl1=position1;
        positionl2=position2;
        %Line Formation
        x0=position0(:,1);
        y0=position0(:,2);
        x1=position1(:,1);
        y1=position1(:,2);
        x2=position2(:,1);
        y2=position2(:,2);
        dx=3.88;
        dy=-2.875;
        d=0.35;
        [xl0,yl0,xl1,yl1,xl2,yl2]=linedistanceformation(dx,dy,x1,y1,x2,y2,d);
        %Get 3 rovers' position
        
         MoveTest(xl0,yl0,positionl0,3*pi/2,int2str(0),clientID,vrep);
         MoveTest(xl1,yl1,positionl1,3*pi/2,int2str(1),clientID,vrep);
         MoveTest(xl2,yl2,positionl2,3*pi/2,int2str(2),clientID,vrep);
         
         
        
        
        
        elapsedTime = toc;

    pause(5);
    
    
    
    %------------------------------CODE HERE------------------------------%
    %destroy connection to v-rep simulation
    vrep.simxPauseSimulation(clientID,vrep.simx_opmode_oneshot_wait);
else
    disp('Failed connecting to remote API server');
end
vrep.delete()

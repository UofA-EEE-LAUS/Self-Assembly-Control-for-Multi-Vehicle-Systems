clc
clear
vrep=remApi('remoteApi');
% close all the potential link
vrep.simxFinish(-1);
%set up connection to v-rep simulation on port 19999
clientID=vrep.simxStart('127.0.0.1',19999,true,true,5000,5);
% open the synchronous mode to control the objects in vrep
vrep.simxSynchronous(clientID,true);
% Simulation Initialization
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);
%clientID is -1 if the connection to the server was NOT possible

if (clientID>-1)
    disp('connected to v-rep');
    elapsedTime = 1;
    
    % rover position
    [returnCode,rover]=vrep.simxGetObjectHandle(clientID,'rover0',vrep.simx_opmode_blocking);
    [returnCode,laser_sensor]=vrep.simxGetObjectHandle(clientID,'laser_sensor',vrep.simx_opmode_oneshot_wait);
    [returnCode,position_ro]=vrep.simxGetObjectPosition(clientID,rover,-1,vrep.simx_opmode_blocking);
    [returnCode] = vrep.simxGetObjectOrientation(clientID,laser_sensor,-1,vrep.simx_opmode_streaming);
    [returnCode, orientations] = vrep.simxGetObjectOrientation(clientID,laser_sensor,-1,vrep.simx_opmode_buffer);
    position_x0=position_ro(:,1);
    position_y0=position_ro(:,2);
    
    % goal
    [returnCode,goal]=vrep.simxGetObjectHandle(clientID,'Dummy_goal',vrep.simx_opmode_blocking);
    [returnCode,position_go]=vrep.simxGetObjectPosition(clientID,goal,-1,vrep.simx_opmode_blocking);
    
    
    % obstacles
    [returnCode,Cuboid11]=vrep.simxGetObjectHandle(clientID,strcat('Cuboid11'),vrep.simx_opmode_blocking);
    [returnCode,cuboid_1]=vrep.simxGetObjectPosition(clientID,Cuboid11,-1,vrep.simx_opmode_blocking);
    [returnCode,Cuboid12]=vrep.simxGetObjectHandle(clientID,strcat('Cuboid12'),vrep.simx_opmode_blocking);
    [returnCode,cuboid_2]=vrep.simxGetObjectPosition(clientID,Cuboid12,-1,vrep.simx_opmode_blocking);
    [returnCode,Cuboid13]=vrep.simxGetObjectHandle(clientID,strcat('Cuboid13'),vrep.simx_opmode_blocking);
    [returnCode,cuboid_3]=vrep.simxGetObjectPosition(clientID,Cuboid13,-1,vrep.simx_opmode_blocking);
    [returnCode,Cuboid14]=vrep.simxGetObjectHandle(clientID,strcat('Cuboid10'),vrep.simx_opmode_blocking);
    [returnCode,cuboid_4]=vrep.simxGetObjectPosition(clientID,Cuboid14,-1,vrep.simx_opmode_blocking);
    [returnCode,Cuboid15]=vrep.simxGetObjectHandle(clientID,strcat('Cuboid'),vrep.simx_opmode_blocking);
    [returnCode,cuboid_5]=vrep.simxGetObjectPosition(clientID,Cuboid15,-1,vrep.simx_opmode_blocking);
    obstacle = [cuboid_1(1), cuboid_2(1), cuboid_3(1),cuboid_4(1), cuboid_5(1);
        cuboid_1(2), cuboid_2(2), cuboid_3(2), cuboid_4(2), cuboid_5(2)];
    
    position = [0,0,0] ; % dummy_goal position
    [ point ] = Path([position_ro(:,1),position_ro(:,2)],[position_go(:,1),position_go(:,2)],obstacle);
    A=[position_ro(:,1)];
    
    for i = 1:30
        if position_ro ~= position_go
            x=point(1,i);
            y=point(2,i);
            display(x)
            display(y)
            Move(x,y,int2str(0),clientID,vrep);
            [returnCode,rover]=vrep.simxGetObjectHandle(clientID,'rover0',vrep.simx_opmode_blocking);
            [returnCode,laser_sensor]=vrep.simxGetObjectHandle(clientID,'laser_sensor',vrep.simx_opmode_oneshot_wait);
            [returnCode,position_ro]=vrep.simxGetObjectPosition(clientID,rover,-1,vrep.simx_opmode_blocking);
            A=[A;position_ro(:,1)];
            %        [ point ] = Path(position_ro,position_go,obstacle)
            i = i+1;
        elseif position_ro == position_go
            vrep.simxPauseSimulation(clientID,vrep.simx_opmode_oneshot_wait);
        end
    end
    plot(A)
    
end

%
%         nxt = min(N);
%         nx = nxt(:,1);
%         ny = nxt(:,2);
%         Move(nx,ny,int2str(0),clientID,vrep);
%         % move to 0,0 position i.e. goal
%         Move(0,0,int2str(0),clientID,vrep);
%         if position == position_ro
%             nxt = min(N);
%             nx = nxt(:,1);
%             ny = nxt(:,2);
%             Move(nx,ny,int2str(0),clientID,vrep);
%